from django.contrib import admin
from .models import Uploded_signs, Verify_sign
# Register your models here.

admin.site.register(Uploded_signs)
admin.site.register(Verify_sign)