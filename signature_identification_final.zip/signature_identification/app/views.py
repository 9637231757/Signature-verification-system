from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from app.verify import authentication, form_varification
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control
from datetime import datetime
from .form import signature_form, document_form
from .models import Uploded_signs,Verify_sign
from .process import extract_sign
import cv2
import numpy as np
import os

# Create your views here.
def index(request):
    # return HttpResponse("This is Home page")    
    return render(request, "index.html")

def log_in(request):
    if request.method == "POST":
        # return HttpResponse("This is Home page")  
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username = username, password = password)

        if user is not None:
            login(request, user)
            messages.success(request, "Log In Successful...!")
            return redirect("dashboard")
        else:
            messages.error(request, "Invalid User...!")
            return redirect("log_in")
    # return HttpResponse("This is Home page")    
    return render(request, "log_in.html")

def register(request):
    if request.method == "POST":
        fname = request.POST['fname']
        lname = request.POST['lname']
        username = request.POST['username']
        password = request.POST['password']
        password1 = request.POST['password1']
        # print(fname, contact_no, ussername)
        verify = authentication(fname, lname, password, password1)
        if verify == "success":
            user = User.objects.create_user(username, password, password1)          #create_user
            user.first_name = fname
            user.last_name = lname
            user.save()
            messages.success(request, "Your Account has been Created.")
            return redirect("/")
            
        else:
            messages.error(request, verify)
            return redirect("register")
    # return HttpResponse("This is Home page")    
    return render(request, "register.html")


@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def log_out(request):
    logout(request)
    messages.success(request, "Log out Successfuly...!")
    return redirect("/")

@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def dashboard(request):
    context = {
        'fname': request.user.first_name,
        }
    
    return render(request, "dashboard.html",context)


@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def upload_sign(request):
    context = {
        'fname': request.user.first_name,
        'form' : signature_form(),
        }
    if request.method == "POST":
        form = signature_form(request.POST, request.FILES)
        if form.is_valid():
            name = form.cleaned_data['name']
            sign = form.cleaned_data['sign']
            verify_form = form_varification(name)
            if verify_form == "success":
                authorize_person = Uploded_signs(name = name, sign = sign)
                authorize_person.save()
                messages.success(request, "Signature Uploaded Successfully!!!")
                return redirect("upload_sign")
            
            else:
                messages.error(request, verify_form)
                return redirect("upload_sign")
        else:
            messages.error(request, "Invalid Form")
            return redirect("upload_sign")
    return render(request, "upload_sign.html",context)

@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def sign_verify(request):
    sign_data = Uploded_signs.objects.all()
    context = {
        'fname': request.user.first_name,
        'form' : document_form(),
        'sign_data' : sign_data
        }
    if request.method == "POST":
        form = document_form(request.POST, request.FILES)
        if form.is_valid():
            doc = form.cleaned_data['uploaded_doc']
            doc_compare = extract_sign(doc)
            # doc_upload = Verify_sign(uploaded_doc = doc)
            # doc_upload.save()
            
            
            # img_data = doc.astype(np.uint8)
            # _, img_str = cv2.imencode('.png', img_data)
            # single_img = cv2.imdecode(np.fromstring(img_str, np.uint8), cv2.IMREAD_COLOR)

            # Initialize the ORB feature detector
            orb = cv2.ORB_create()

            # Detect keypoints and compute descriptors for the reference image
            kp1, des1 = orb.detectAndCompute(doc_compare, None)

            # Initialize the brute-force matcher
            bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

            # Initialize the list to store the matching percentages
            matching_percentages = {}

            # Loop through all media/signatures in a directory
            for filename in os.listdir('media/signatures'):
                if filename.endswith('.jpg') or filename.endswith('.png'):
                    # Load the image to be compared
                    img2 = cv2.imread(os.path.join('media/signatures', filename))

                    # Detect keypoints and compute descriptors for the comparison image
                    kp2, des2 = orb.detectAndCompute(img2, None)

                    # Match the descriptors from both images
                    matches = bf.match(des2, des1)

                    # Sort the matches by distance (i.e. similarity)
                    matches = sorted(matches, key=lambda x: x.distance)

                    # Draw the top matches on a new image
                    match_img = cv2.drawMatches(img2, kp2, doc_compare, kp1, matches[:10], None, flags=2)

                    # Calculate the matching percentage based on the number of matches
                    matching_percentage = len(matches) * 100 / len(kp1)

                    # Append the matching percentage to the list
                    matching_percentages[filename]=matching_percentage

                    # Display the matching percentage and the top matches image
                    print(f"Matching percentage with {filename}: {matching_percentage:.2f}%")

                    # cv2.namedWindow('Top Matches', cv2.WINDOW_NORMAL)
                    # cv2.resizeWindow('Top Matches', 800, 600)
                    # cv2.imshow('Top Matches', match_img)
                    # cv2.waitKey(0)
                    # cv2.destroyAllWindows()

            
            max_pair = max(matching_percentages.items(), key=lambda x: x[1])
            print(max_pair)
            if max_pair[1] < 20:
                doc_upload = Verify_sign(uploaded_doc = doc, match_file = "/media/signatures/" + max_pair[0], match_percentage = "Not Match")
                doc_upload.save()
            else:
                doc_upload = Verify_sign(uploaded_doc = doc, match_file = "/media/signatures/" + max_pair[0], match_percentage = max_pair[1])
                doc_upload.save()
            return redirect("results")

        else:
            messages.error(request, "Invalid Form")
            return redirect("upload_sign")
    return render(request, "sign_verify.html",context)

@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def results(request):
    sign_data = Uploded_signs.objects.all()
    verify_data = Verify_sign.objects.last()
    context = {
        'fname': request.user.first_name,
        'sign_data' : sign_data,
        'verify_data' : verify_data
        }
    
    return render(request, "results.html",context)