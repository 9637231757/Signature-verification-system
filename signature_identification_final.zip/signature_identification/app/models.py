from django.db import models

# Create your models here.
class Uploded_signs(models.Model):
    name = models.CharField(max_length=70)
    sign = models.ImageField(upload_to="signatures/")

    def __str__(self):
        return self.name

class Verify_sign(models.Model):
    uploaded_doc = models.ImageField()
    match_file = models.CharField(max_length=70)
    match_percentage = models.CharField(max_length=70)

    def __str__(self) -> str:
        return super().__str__()