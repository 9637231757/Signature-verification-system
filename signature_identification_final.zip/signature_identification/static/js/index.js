const printBtn = document.getElementById("printBtn");
printBtn.addEventListener("click", () => print());
